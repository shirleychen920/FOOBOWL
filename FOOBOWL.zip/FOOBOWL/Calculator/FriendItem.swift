//
//  FriendItem.swift
//  Calculator
//
//  Created by Wang Jingtao on 5/30/16.
//  Copyright © 2016 ShirleyChen. All rights reserved.
//
import Foundation

struct FriendItem
{
    let name: String
}